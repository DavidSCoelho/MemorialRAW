# projetoFinalMod5
Projeto final do Programadores Cariocas

Neste projeto o tema proposto foi livre para a escolha dos grupos. 
Nosso grupo escolheu o tema de uma instituição prestadora de serviços funerários, onde o sistema permite a consulta, o cadastro, a edição e a exclusão de dados relacionados aos serviços e informações de clientes e fornecedores da empresa.

Nome do banco de dados: funerariadb

Distribuição de tasks:
Nome da tabela - Responsável

CLIENTE - CAIO <br>
DEPENDENTE - LEILA <br>
SERVIÇO - ENRICK <br>
PRODUTO - DAVID <br>
LOCAÇÕES - ROGERIO JUNIOR <br>
